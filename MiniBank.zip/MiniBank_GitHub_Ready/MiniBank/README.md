# MiniBank — Core Banking Simulation (Java)

**Subject:** CEUE203 – Object-Oriented Programming (Java) | **Semester:** 3 | **Year:** 2026-27
**Student ID:** 25CE005

A console-based banking simulation demonstrating OOP, generics, collections, exceptions,
annotations + reflection, regex validation, file I/O (NIO + serialization), multithreading,
and JUnit 5 testing.

## Project Structure

```
minibank/
├── src/
│   ├── exception/   BankException, AccountNotFoundException, InsufficientFundsException, InvalidAmountException
│   ├── model/       Account, SavingsAccount, CurrentAccount, FixedDepositAccount, Customer,
│   │                InterestBearing, Premium, Transactable, TransactionType, Command
│   │   └── annotation/  Id, MaxLength, Positive
│   ├── service/     MiniBank (main), BankService, AccountStore, TransactionProcessor, AccountWorker,
│   │                TransactionBuffer, TransferLockDemo, WithdrawRule, BankSession
│   └── util/        Repository, AnnotationValidator, CommandParser, StatementFormatter, Validator,
│                    StatePersister, TransactionLog, ReportGenerator
├── tests/service/   MiniBankTest (JUnit 5)
├── build.bat / build.sh   Compile + create minibank.jar
└── run.bat / run.sh       Run the application
```

## Requirements
- JDK 17 or newer (records, pattern-matching `instanceof`, switch arrows are used)

## Build and Run

**Windows**
```
build.bat
run.bat
```

**Linux / macOS**
```
./build.sh
./run.sh
```

Or manually:
```
javac -d out $(find src -name "*.java")
java -cp out service.MiniBank
java -cp out service.TransferLockDemo
```

Run `MiniBank` from the project root: it creates `data/` (saved accounts, report) and `logs/` (transaction log) there.

## Run the JUnit tests
Download `junit-platform-console-standalone-<version>.jar` from Maven Central, place it in `lib/`, then:
```
javac -cp "lib/*;out" -d out tests/service/MiniBankTest.java
java -jar lib/junit-platform-console-standalone-<version>.jar execute --class-path out --select-class service.MiniBankTest
```
(Use `:` instead of `;` on Linux/macOS.)
